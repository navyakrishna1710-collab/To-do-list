let taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];


function render() {
taskList.innerHTML = "";
tasks.forEach((task, index) => {
const li = document.createElement("li");
li.textContent = task;


const editBtn = document.createElement("button");
editBtn.textContent = "Edit";
editBtn.onclick = () => {
const newText = prompt("Edit task:", task);
if (newText && newText.trim() !== "") {
tasks[index] = newText.trim();
saveAndRender();
}
};


const delBtn = document.createElement("button");
delBtn.textContent = "Delete";
delBtn.classList.add("delete");
delBtn.onclick = () => {
tasks.splice(index, 1);
saveAndRender();
};

li.appendChild(editBtn);
li.appendChild(delBtn);
taskList.appendChild(li);
});
}


addBtn.onclick = () => {
const text = taskInput.value.trim();
if (text) {
tasks.push(text);
saveAndRender();
taskInput.value = "";
}
};


function saveAndRender() {
localStorage.setItem("tasks", JSON.stringify(tasks));
render();
}
render();

